URL_SERVICE = "https://8c7983f0-c30d-46d5-a9d5-b71e35567af9.serverhub.praktikum-services.ru"
DOC_PATH = "/docs/"
CREATE_ORDER = "/api/v1/orders"
RECEIVE_ORDER = "/v1/orders/track?t=" # после t= указываем номер трека